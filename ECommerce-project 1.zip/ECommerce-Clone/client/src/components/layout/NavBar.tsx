import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Search, ShoppingCart, User as UserIcon, LogOut, Package, ChevronDown } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useCart } from "@/hooks/use-cart";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function NavBar() {
  const [, setLocation] = useLocation();
  const { user, isAuthenticated, logout } = useAuth();
  const { data: cartItems } = useCart();
  const [searchQuery, setSearchQuery] = useState("");

  const cartItemCount = cartItems?.reduce((acc, item) => acc + item.quantity, 0) || 0;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setLocation(`/?search=${encodeURIComponent(searchQuery)}`);
    } else {
      setLocation("/");
    }
  };

  return (
    <nav className="bg-primary text-primary-foreground sticky top-0 z-50 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Logo */}
          <Link href="/" className="flex items-center flex-shrink-0 group cursor-pointer">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center shadow-sm group-hover:rotate-12 transition-transform duration-300">
                <span className="text-primary font-bold text-xl italic">MK</span>
              </div>
              <span className="font-display font-bold text-2xl italic tracking-tight group-hover:opacity-90 transition-opacity">
                MK Mart<span className="text-secondary">.</span>
              </span>
            </div>
          </Link>

          {/* Search Bar */}
          <div className="flex-1 max-w-2xl hidden md:block">
            <form onSubmit={handleSearch} className="relative">
              <Input 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search for products, brands and more" 
                className="w-full bg-white text-foreground rounded-sm border-none pl-4 pr-10 py-5 shadow-sm focus-visible:ring-0 focus-visible:ring-offset-0"
              />
              <button type="submit" className="absolute right-0 top-0 h-full px-4 text-primary hover:text-primary/80 transition-colors">
                <Search className="h-5 w-5" />
              </button>
            </form>
          </div>

          {/* Right Actions */}
          <div className="flex items-center gap-2 sm:gap-6">
            {isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="flex items-center gap-1 hover:text-white/80 transition-colors font-medium cursor-pointer outline-none">
                    <UserIcon className="h-5 w-5" />
                    <span className="hidden sm:inline">{user?.firstName || 'Profile'}</span>
                    <ChevronDown className="h-4 w-4" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48 bg-white border-border/50">
                  <div className="px-4 py-3 border-b">
                    <p className="text-sm font-medium text-foreground">{user?.firstName} {user?.lastName}</p>
                    <p className="text-xs text-muted-foreground truncate">{user?.email}</p>
                  </div>
                  <DropdownMenuItem onClick={() => setLocation('/profile')} className="cursor-pointer py-2.5">
                    <UserIcon className="mr-2 h-4 w-4" />
                    <span>My Profile</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation('/orders')} className="cursor-pointer py-2.5">
                    <Package className="mr-2 h-4 w-4" />
                    <span>My Orders</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => logout()} className="cursor-pointer py-2.5 text-destructive focus:text-destructive">
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Logout</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button 
                onClick={() => window.location.href = '/api/login'} 
                variant="secondary" 
                className="bg-white text-primary hover:bg-gray-50 font-bold px-8 rounded-sm shadow-sm transition-transform active:scale-95"
              >
                Login
              </Button>
            )}

            <Link href="/cart" className="flex items-center gap-2 hover:text-white/80 transition-colors cursor-pointer group">
              <div className="relative">
                <ShoppingCart className="h-6 w-6" />
                {cartItemCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-secondary text-secondary-foreground text-[10px] font-bold h-4 w-4 flex items-center justify-center rounded-full group-hover:scale-110 transition-transform">
                    {cartItemCount}
                  </span>
                )}
              </div>
              <span className="hidden sm:inline font-medium">Cart</span>
            </Link>
          </div>
        </div>
        
        {/* Mobile Search */}
        <div className="pb-3 md:hidden">
          <form onSubmit={handleSearch} className="relative">
            <Input 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search for products..." 
              className="w-full bg-white text-foreground rounded-sm border-none pl-4 pr-10 shadow-sm"
            />
            <button type="submit" className="absolute right-0 top-0 h-full px-4 text-primary">
              <Search className="h-4 w-4" />
            </button>
          </form>
        </div>
      </div>
    </nav>
  );
}
