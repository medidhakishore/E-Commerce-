import { Link } from "wouter";
import { MapPin, Phone, Mail } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-[#172337] text-gray-300 py-12 border-t border-gray-800 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-white font-semibold mb-4 tracking-wide uppercase text-sm text-gray-500">About</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-white transition-colors hover:underline">Contact Us</a></li>
              <li><a href="#" className="hover:text-white transition-colors hover:underline">About Us</a></li>
              <li><a href="#" className="hover:text-white transition-colors hover:underline">Careers</a></li>
              <li><a href="#" className="hover:text-white transition-colors hover:underline">Press</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-semibold mb-4 tracking-wide uppercase text-sm text-gray-500">Help</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-white transition-colors hover:underline">Payments</a></li>
              <li><a href="#" className="hover:text-white transition-colors hover:underline">Shipping</a></li>
              <li><a href="#" className="hover:text-white transition-colors hover:underline">Cancellation & Returns</a></li>
              <li><a href="#" className="hover:text-white transition-colors hover:underline">FAQ</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-semibold mb-4 tracking-wide uppercase text-sm text-gray-500">Policy</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-white transition-colors hover:underline">Return Policy</a></li>
              <li><a href="#" className="hover:text-white transition-colors hover:underline">Terms of Use</a></li>
              <li><a href="#" className="hover:text-white transition-colors hover:underline">Security</a></li>
              <li><a href="#" className="hover:text-white transition-colors hover:underline">Privacy</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-semibold mb-4 tracking-wide uppercase text-sm text-gray-500">Registered Office</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 mt-0.5 shrink-0" />
                <span>MK Mart Internet Private Limited, Buildings Alyssa, Begonia & Clove Embassy Tech Village, Outer Ring Road, Bengaluru, 560103, Karnataka, India</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 shrink-0" />
                <span>1800 202 0000</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 shrink-0" />
                <span>support@mkmart.com</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center text-sm gap-4">
          <p>&copy; {new Date().getFullYear()} MK Mart. All rights reserved.</p>
          <div className="flex gap-4">
            <span className="font-display font-bold text-xl italic text-white">
              MK Mart<span className="text-secondary">.</span>
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
