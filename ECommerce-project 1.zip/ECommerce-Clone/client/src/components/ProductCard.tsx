import { Link } from "wouter";
import { ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Product } from "@shared/schema";
import { useAddToCart } from "@/hooks/use-cart";
import { useAuth } from "@/hooks/use-auth";
import { redirectToLogin } from "@/lib/auth-utils";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/utils";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { isAuthenticated } = useAuth();
  const { mutate: addToCart, isPending } = useAddToCart();
  const { toast } = useToast();

  {/* default electronic product image placeholder if missing */}
  const defaultImage = `https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&h=500&fit=crop&q=80`;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault(); // Prevent navigating to product detail
    
    if (!isAuthenticated) {
      redirectToLogin(toast);
      return;
    }

    addToCart(
      { productId: product.id, quantity: 1 },
      {
        onSuccess: () => {
          toast({
            title: "Added to Cart",
            description: `${product.name} added to your cart.`,
          });
        },
        onError: () => {
          toast({
            title: "Error",
            description: "Could not add item to cart.",
            variant: "destructive",
          });
        }
      }
    );
  };

  return (
    <Link href={`/product/${product.id}`} className="group block h-full">
      <div className="bg-card rounded-xl border border-border/50 overflow-hidden hover-elevate h-full flex flex-col group-hover:border-primary/20">
        <div className="relative aspect-square overflow-hidden bg-white p-4 flex items-center justify-center">
          <img 
            src={product.imageUrl || defaultImage} 
            alt={product.name} 
            className="object-contain w-full h-full mix-blend-multiply group-hover:scale-105 transition-transform duration-500"
          />
          {product.isFeatured && (
            <div className="absolute top-2 left-2 bg-secondary text-secondary-foreground text-xs font-bold px-2 py-1 rounded shadow-sm">
              Featured
            </div>
          )}
        </div>
        
        <div className="p-4 flex flex-col flex-1 border-t border-border/30">
          <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">{product.category}</p>
          <h3 className="font-medium text-foreground line-clamp-2 mb-2 group-hover:text-primary transition-colors flex-1">
            {product.name}
          </h3>
          
          <div className="mt-auto">
            <div className="flex items-end gap-2 mb-3">
              <span className="text-xl font-bold text-foreground">
                {formatCurrency(Number(product.price))}
              </span>
              <span className="text-sm text-muted-foreground line-through pb-0.5">
                {formatCurrency(Number(product.price) * 1.2)} {/* Fake original price */}
              </span>
              <span className="text-xs font-semibold text-green-600 pb-1">
                20% off
              </span>
            </div>
            
            <Button 
              onClick={handleAddToCart}
              disabled={isPending || product.stock <= 0}
              className="w-full bg-primary/10 text-primary hover:bg-primary hover:text-white transition-colors duration-300 font-semibold"
            >
              {isPending ? "Adding..." : product.stock > 0 ? (
                <>
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Add to Cart
                </>
              ) : "Out of Stock"}
            </Button>
          </div>
        </div>
      </div>
    </Link>
  );
}
