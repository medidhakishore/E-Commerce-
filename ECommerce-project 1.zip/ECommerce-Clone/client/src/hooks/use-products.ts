import { useQuery } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import type { Product } from "@shared/schema";

export function useProducts(search?: string, category?: string) {
  return useQuery({
    queryKey: [api.products.list.path, search, category],
    queryFn: async () => {
      const url = new URL(api.products.list.path, window.location.origin);
      if (search) url.searchParams.set("search", search);
      if (category) url.searchParams.set("category", category);
      
      const res = await fetch(url.toString(), { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch products");
      return (await res.json()) as Product[];
    },
  });
}

export function useProduct(id: number) {
  return useQuery({
    queryKey: [api.products.get.path, id],
    queryFn: async () => {
      if (!id) return null;
      const url = buildUrl(api.products.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch product");
      return (await res.json()) as Product;
    },
    enabled: !!id,
  });
}

export function useCategories() {
  return useQuery({
    queryKey: [api.products.categories.path],
    queryFn: async () => {
      const res = await fetch(api.products.categories.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch categories");
      return (await res.json()) as string[];
    },
  });
}
