import { useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Search, ShoppingCart, Package } from "lucide-react";
import { Layout } from "@/components/layout/Layout";
import { ProductCard } from "@/components/ProductCard";
import { useProducts, useCategories } from "@/hooks/use-products";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  const searchQuery = searchParams.get("search") || "";
  
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  
  const { data: products, isLoading: productsLoading } = useProducts(searchQuery, selectedCategory);
  const { data: categories, isLoading: categoriesLoading } = useCategories();

  // Categories placeholder icons logic (just visual)
  const getCategoryIcon = (name: string) => {
    return `https://ui-avatars.com/api/?name=${name}&background=f3f4f6&color=2874f0&rounded=true&bold=true`;
  };

  return (
    <Layout>
      {/* Category Nav Row */}
      <div className="bg-card rounded-xl shadow-sm border border-border/50 p-4 mb-6 overflow-x-auto hide-scrollbar">
        <div className="flex items-center gap-6 min-w-max">
          <button 
            onClick={() => setSelectedCategory("")}
            className={`flex flex-col items-center gap-2 group transition-opacity ${selectedCategory === "" ? "opacity-100" : "opacity-60 hover:opacity-100"}`}
          >
            <div className={`w-16 h-16 rounded-full flex items-center justify-center p-1 border-2 transition-colors ${selectedCategory === "" ? "border-primary" : "border-transparent group-hover:border-primary/50"}`}>
              <img src={getCategoryIcon('All')} alt="All" className="w-full h-full rounded-full object-cover" />
            </div>
            <span className={`text-sm font-medium ${selectedCategory === "" ? "text-primary" : "text-foreground"}`}>Top Offers</span>
          </button>
          
          {categoriesLoading ? (
            Array(6).fill(0).map((_, i) => (
              <div key={i} className="flex flex-col items-center gap-2">
                <Skeleton className="w-16 h-16 rounded-full" />
                <Skeleton className="w-16 h-4" />
              </div>
            ))
          ) : (
            categories?.map((cat) => {
              const icons: Record<string, string> = {
                "Electronics": "https://cdn-icons-png.flaticon.com/512/3659/3659899.png",
                "Fashion": "https://cdn-icons-png.flaticon.com/512/3050/3050239.png",
                "Accessories": "https://cdn-icons-png.flaticon.com/512/2611/2611130.png",
                "Kids": "https://cdn-icons-png.flaticon.com/512/921/921525.png",
                "Groceries": "https://cdn-icons-png.flaticon.com/512/1995/1995564.png"
              };
              return (
                <button 
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`flex flex-col items-center gap-2 group transition-opacity ${selectedCategory === cat ? "opacity-100" : "opacity-60 hover:opacity-100"}`}
                >
                  <div className={`w-16 h-16 rounded-full flex items-center justify-center p-1 border-2 transition-colors ${selectedCategory === cat ? "border-primary" : "border-transparent group-hover:border-primary/50"}`}>
                    <img src={icons[cat] || getCategoryIcon(cat)} alt={cat} className="w-full h-full rounded-full object-contain p-2" />
                  </div>
                  <span className={`text-sm font-medium ${selectedCategory === cat ? "text-primary" : "text-foreground"}`}>{cat}</span>
                </button>
              );
            })
          )}
        </div>
      </div>

      {/* Hero Banner (Only show if not searching) */}
      {!searchQuery && !selectedCategory && (
        <div className="space-y-8">
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="rounded-2xl overflow-hidden relative group bg-gradient-to-r from-blue-900 to-primary h-48 sm:h-64 md:h-80 cursor-pointer"
            onClick={() => setSelectedCategory("Electronics")}
          >
            <img 
              src="https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=1200&q=80" 
              alt="Hero Banner" 
              className="w-full h-full object-cover mix-blend-overlay opacity-60"
            />
            <div className="absolute inset-0 flex flex-col justify-center px-8 md:px-16">
              <h1 className="text-3xl md:text-5xl font-display font-bold text-white mb-2 leading-tight max-w-lg">
                MK Mart <br/><span className="text-secondary text-2xl md:text-4xl">Exclusive Offers</span>
              </h1>
              <p className="text-white/90 text-lg mb-6 max-w-md hidden sm:block">
                Up to 80% off on premium electronics and fashion. Only for limited time!
              </p>
              <div className="flex gap-4">
                <div className="bg-white/20 backdrop-blur-md px-4 py-2 rounded-lg border border-white/30 text-white font-bold animate-pulse">
                  Flash Sale Live!
                </div>
              </div>
            </div>
          </motion.div>

          {/* Exclusive Offers Section */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <motion.div 
              onClick={() => setSelectedCategory("Electronics")}
              whileHover={{ scale: 1.05, y: -5 }}
              className="bg-gradient-to-br from-orange-500 to-red-600 rounded-xl p-6 text-white relative overflow-hidden group cursor-pointer shadow-md hover:shadow-xl transition-shadow"
            >
              <div className="relative z-10">
                <span className="text-xs font-bold uppercase tracking-wider opacity-80">Tech Deals</span>
                <h3 className="text-2xl font-bold mt-1">Laptops & PCs</h3>
                <p className="text-sm mt-2 opacity-90">Extra ₹5000 Off on Exchange</p>
              </div>
              <div className="absolute right-[-20px] bottom-[-20px] opacity-10 group-hover:scale-110 transition-transform">
                <Search className="w-40 h-40 rotate-12" />
              </div>
            </motion.div>
            <motion.div 
              onClick={() => setSelectedCategory("Fashion")}
              whileHover={{ scale: 1.05, y: -5 }}
              className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl p-6 text-white relative overflow-hidden group cursor-pointer shadow-md hover:shadow-xl transition-shadow"
            >
              <div className="relative z-10">
                <span className="text-xs font-bold uppercase tracking-wider opacity-80">Fashion Week</span>
                <h3 className="text-2xl font-bold mt-1">Summer Styles</h3>
                <p className="text-sm mt-2 opacity-90">Buy 2 Get 1 Free</p>
              </div>
              <div className="absolute right-[-20px] bottom-[-20px] opacity-10 group-hover:scale-110 transition-transform">
                <ShoppingCart className="w-40 h-40 rotate-12" />
              </div>
            </motion.div>
            <motion.div 
              onClick={() => setSelectedCategory("Groceries")}
              whileHover={{ scale: 1.05, y: -5 }}
              className="bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl p-6 text-white relative overflow-hidden group cursor-pointer shadow-md hover:shadow-xl transition-shadow"
            >
              <div className="relative z-10">
                <span className="text-xs font-bold uppercase tracking-wider opacity-80">Fresh & Healthy</span>
                <h3 className="text-2xl font-bold mt-1">Organic Groceries</h3>
                <p className="text-sm mt-2 opacity-90">Free Delivery on Orders 300+</p>
              </div>
              <div className="absolute right-[-20px] bottom-[-20px] opacity-10 group-hover:scale-110 transition-transform">
                <Package className="w-40 h-40 rotate-12" />
              </div>
            </motion.div>
          </div>
        </div>
      )}

      {/* Results Header */}
      <div className="mb-6 flex items-center justify-between">
        <h2 className="text-xl md:text-2xl font-display font-bold">
          {searchQuery ? `Search Results for "${searchQuery}"` : selectedCategory ? `${selectedCategory} Products` : 'Best of Electronics'}
        </h2>
        {products && <span className="text-muted-foreground text-sm">{products.length} items</span>}
      </div>

      {/* Product Grid */}
      {productsLoading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {Array(10).fill(0).map((_, i) => (
            <div key={i} className="bg-card rounded-xl border p-4 space-y-3">
              <Skeleton className="w-full aspect-square rounded-lg" />
              <Skeleton className="w-2/3 h-4" />
              <Skeleton className="w-full h-4" />
              <Skeleton className="w-1/3 h-6" />
              <Skeleton className="w-full h-10 mt-4" />
            </div>
          ))}
        </div>
      ) : products?.length === 0 ? (
        <div className="bg-card rounded-xl border p-12 text-center flex flex-col items-center">
          <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mb-4">
            <Search className="w-12 h-12 text-muted-foreground" />
          </div>
          <h3 className="text-xl font-bold mb-2">No products found</h3>
          <p className="text-muted-foreground mb-6">Try adjusting your search or category filters.</p>
          {(searchQuery || selectedCategory) && (
            <button 
              onClick={() => {
                setSelectedCategory("");
                window.history.pushState({}, '', '/');
                window.location.reload();
              }}
              className="text-primary hover:underline font-medium"
            >
              Clear all filters
            </button>
          )}
        </div>
      ) : (
        <motion.div 
          initial="hidden"
          animate="show"
          variants={{
            hidden: { opacity: 0 },
            show: {
              opacity: 1,
              transition: { staggerChildren: 0.05 }
            }
          }}
          className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4"
        >
          {products?.map((product) => (
            <motion.div 
              key={product.id}
              variants={{
                hidden: { opacity: 0, y: 20 },
                show: { opacity: 1, y: 0 }
              }}
            >
              <ProductCard product={product} />
            </motion.div>
          ))}
        </motion.div>
      )}
    </Layout>
  );
}
