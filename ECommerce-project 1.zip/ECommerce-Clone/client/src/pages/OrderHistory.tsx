import { Layout } from "@/components/layout/Layout";
import { useOrders } from "@/hooks/use-orders";
import { formatCurrency } from "@/lib/utils";
import { Link } from "wouter";
import { Package, ChevronRight, MapPin } from "lucide-react";
import { format } from "date-fns";

export default function OrderHistory() {
  const { data: orders, isLoading } = useOrders();

  if (isLoading) {
    return (
      <Layout>
        <div className="animate-pulse space-y-4 max-w-4xl mx-auto">
          <div className="h-48 bg-card rounded-xl border"></div>
          <div className="h-48 bg-card rounded-xl border"></div>
        </div>
      </Layout>
    );
  }

  if (!orders || orders.length === 0) {
    return (
      <Layout>
        <div className="bg-card rounded-xl border p-12 text-center shadow-sm max-w-2xl mx-auto mt-10">
          <div className="w-24 h-24 bg-blue-50 text-primary rounded-full flex items-center justify-center mx-auto mb-6">
            <Package className="w-12 h-12" />
          </div>
          <h2 className="text-2xl font-bold mb-2">No orders found</h2>
          <p className="text-muted-foreground mb-8">Looks like you haven't placed any orders yet.</p>
          <Link href="/" className="text-primary hover:underline font-medium bg-primary/10 px-6 py-3 rounded-md">
            Start Shopping
          </Link>
        </div>
      </Layout>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'delivered': return 'text-green-600 bg-green-50 border-green-200';
      case 'cancelled': return 'text-red-600 bg-red-50 border-red-200';
      case 'shipped': return 'text-blue-600 bg-blue-50 border-blue-200';
      default: return 'text-amber-600 bg-amber-50 border-amber-200';
    }
  };

  return (
    <Layout>
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-display font-bold mb-6">My Orders</h1>
        
        <div className="space-y-4">
          {orders.map((order) => (
            <div key={order.id} className="bg-card rounded-xl border shadow-sm hover:shadow-md transition-shadow overflow-hidden group cursor-pointer">
              {/* Order Header */}
              <div className="bg-gray-50 p-4 border-b flex flex-wrap gap-4 justify-between items-center">
                <div className="flex gap-8 text-sm">
                  <div>
                    <p className="text-muted-foreground mb-1 uppercase text-xs font-bold tracking-wide">Order Placed</p>
                    <p className="font-medium text-foreground">
                      {order.createdAt ? format(new Date(order.createdAt), "dd MMM yyyy") : "N/A"}
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground mb-1 uppercase text-xs font-bold tracking-wide">Total</p>
                    <p className="font-medium text-foreground">{formatCurrency(Number(order.totalAmount))}</p>
                  </div>
                  <div className="hidden sm:block">
                    <p className="text-muted-foreground mb-1 uppercase text-xs font-bold tracking-wide">Ship To</p>
                    <div className="flex items-center gap-1 font-medium text-primary">
                      <MapPin className="w-3 h-3" />
                      <span className="truncate max-w-[150px]" title={order.shippingAddress}>{order.shippingAddress}</span>
                    </div>
                  </div>
                </div>
                <div className="text-sm font-medium flex items-center gap-2">
                  <span className={`px-3 py-1 rounded-full border text-xs font-bold uppercase tracking-wider ${getStatusColor(order.status)}`}>
                    {order.status}
                  </span>
                  <span className="text-primary group-hover:underline flex items-center">
                    Order Details <ChevronRight className="w-4 h-4 ml-1" />
                  </span>
                </div>
              </div>
              
              {/* Order Items */}
              <div className="p-0">
                {order.items.map((item, idx) => (
                  <div key={item.id} className={`p-4 flex gap-4 items-center ${idx !== order.items.length - 1 ? 'border-b border-gray-100' : ''}`}>
                    <div className="w-20 h-20 shrink-0 bg-white p-1 border rounded-md">
                      <img 
                        src={item.product.imageUrl || `https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=150&h=150&fit=crop`} 
                        alt={item.product.name} 
                        className="w-full h-full object-contain"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-foreground line-clamp-1">{item.product.name}</h4>
                      <p className="text-sm text-muted-foreground mt-1">Qty: {item.quantity}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="font-bold text-foreground">{formatCurrency(Number(item.price))}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </Layout>
  );
}
