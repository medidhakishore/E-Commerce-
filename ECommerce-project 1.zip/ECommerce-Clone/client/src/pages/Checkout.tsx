import { useState } from "react";
import { useLocation } from "wouter";
import { Layout } from "@/components/layout/Layout";
import { useCart } from "@/hooks/use-cart";
import { useCreateOrder } from "@/hooks/use-orders";
import { formatCurrency } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/use-auth";
import { CheckCircle2, MapPin, Home, Briefcase } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Checkout() {
  const [, setLocation] = useLocation();
  const { data: cartItems, isLoading: cartLoading } = useCart();
  const { mutate: createOrder, isPending: creatingOrder } = useCreateOrder();
  const { user } = useAuth();
  const { toast } = useToast();

  const [address, setAddress] = useState("");
  const [landmark, setLandmark] = useState("");
  const [addressType, setAddressType] = useState("home");
  const [isSuccess, setIsSuccess] = useState(false);

  const totalAmount = cartItems?.reduce((acc, item) => acc + (Number(item.product.price) * item.quantity), 0) || 0;

  const handleCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!address.trim()) {
      toast({ title: "Validation Error", description: "Please enter a shipping address", variant: "destructive" });
      return;
    }

    createOrder(
      { shippingAddress: address, landmark: landmark || undefined, addressType },
      {
        onSuccess: () => {
          setIsSuccess(true);
          setTimeout(() => setLocation('/orders'), 3000);
        },
        onError: (err) => {
          toast({ title: "Order Failed", description: err.message, variant: "destructive" });
        }
      }
    );
  };

  if (isSuccess) {
    return (
      <Layout>
        <div className="flex flex-col items-center justify-center min-h-[60vh] text-center space-y-6">
          <div className="w-24 h-24 rounded-full bg-green-100 flex items-center justify-center text-green-600 animate-in zoom-in duration-500">
            <CheckCircle2 className="w-12 h-12" />
          </div>
          <h1 className="text-3xl font-display font-bold text-foreground">Order Placed Successfully!</h1>
          <p className="text-lg text-muted-foreground max-w-md">
            Thank you for shopping with us. Your order will be delivered soon.
          </p>
          <p className="text-sm text-muted-foreground animate-pulse">Redirecting to your orders...</p>
        </div>
      </Layout>
    );
  }

  if (cartLoading) return <Layout><div className="p-8 text-center">Loading...</div></Layout>;
  if (!cartItems?.length) {
    setLocation('/cart');
    return null;
  }

  return (
    <Layout>
      <div className="flex flex-col lg:flex-row gap-8">
        {/* Left: Address Form */}
        <div className="w-full lg:w-2/3 space-y-6">
          <div className="bg-primary text-white p-4 rounded-t-xl font-bold flex items-center justify-between">
            <span className="flex items-center gap-3"><span className="bg-white text-primary w-6 h-6 rounded-sm flex items-center justify-center text-sm">1</span> LOGIN</span>
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div className="bg-white border rounded-b-xl -mt-6 p-6 mb-6 shadow-sm flex justify-between items-center text-sm">
            <div>
              <span className="font-semibold">{user?.firstName} {user?.lastName}</span>
              <span className="text-muted-foreground ml-2">{user?.email}</span>
            </div>
          </div>

          <div className="bg-primary text-white p-4 rounded-t-xl font-bold flex items-center gap-3">
            <span className="bg-white text-primary w-6 h-6 rounded-sm flex items-center justify-center text-sm">2</span> DELIVERY ADDRESS
          </div>
          <div className="bg-white border rounded-b-xl -mt-6 p-6 shadow-sm">
            <form onSubmit={handleCheckout} className="space-y-6">
              {/* Address Type Selection */}
              <div className="grid gap-3">
                <Label className="font-semibold">Address Type</Label>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { value: "home", label: "Home", icon: Home },
                    { value: "work", label: "Work", icon: Briefcase },
                    { value: "other", label: "Other", icon: MapPin }
                  ].map(({ value, label, icon: Icon }) => (
                    <button
                      key={value}
                      type="button"
                      onClick={() => setAddressType(value)}
                      className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all ${
                        addressType === value 
                          ? "border-primary bg-primary/5" 
                          : "border-gray-200 hover:border-primary/50"
                      }`}
                    >
                      <Icon className={`w-5 h-5 ${addressType === value ? "text-primary" : "text-gray-400"}`} />
                      <span className={`text-sm font-medium ${addressType === value ? "text-primary" : "text-gray-600"}`}>
                        {label}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Full Address */}
              <div className="grid gap-2">
                <Label htmlFor="address" className="font-semibold">Full Shipping Address</Label>
                <Textarea 
                  id="address" 
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Enter flat/house no, building name, apartment, street..." 
                  className="min-h-[100px] resize-none focus-visible:ring-primary"
                  required
                />
              </div>

              {/* Landmark */}
              <div className="grid gap-2">
                <Label htmlFor="landmark" className="font-semibold">Landmark (Optional)</Label>
                <Input 
                  id="landmark"
                  value={landmark}
                  onChange={(e) => setLandmark(e.target.value)}
                  placeholder="e.g., Near Starbucks, Opposite Blue Gate, etc."
                  className="focus-visible:ring-primary"
                />
              </div>

              <Button 
                type="submit" 
                disabled={creatingOrder}
                className="bg-[#fb641b] hover:bg-[#ef5e1a] text-white px-8 py-6 rounded-sm shadow-md font-bold uppercase tracking-wide w-full"
              >
                {creatingOrder ? "Processing..." : "Deliver Here & Continue"}
              </Button>
            </form>
          </div>
        </div>

        {/* Right: Order Summary */}
        <div className="w-full lg:w-1/3">
          <div className="bg-card rounded-xl border shadow-sm sticky top-24">
            <div className="p-4 border-b">
              <h3 className="font-bold text-gray-500 uppercase tracking-wide text-sm">Order Summary</h3>
            </div>
            <div className="p-0">
              <div className="max-h-[40vh] overflow-y-auto p-4 space-y-4 hide-scrollbar">
                {cartItems.map((item) => (
                  <div key={item.id} className="flex gap-4 items-center">
                    <img src={item.product.imageUrl || `https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=100&h=100&fit=crop`} alt={item.product.name} className="w-12 h-12 object-contain" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{item.product.name}</p>
                      <p className="text-xs text-muted-foreground">Qty: {item.quantity}</p>
                    </div>
                    <div className="text-sm font-bold">
                      {formatCurrency(Number(item.product.price) * item.quantity)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="p-4 bg-gray-50 border-t rounded-b-xl">
              <div className="flex justify-between items-center font-bold text-lg">
                <span>Amount Payable</span>
                <span>{formatCurrency(totalAmount)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
