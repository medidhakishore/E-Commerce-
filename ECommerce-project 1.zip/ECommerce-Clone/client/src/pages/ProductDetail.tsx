import { useParams } from "wouter";
import { Layout } from "@/components/layout/Layout";
import { useProduct } from "@/hooks/use-products";
import { useAddToCart } from "@/hooks/use-cart";
import { useAuth } from "@/hooks/use-auth";
import { redirectToLogin } from "@/lib/auth-utils";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ShoppingCart, Zap, Star, ShieldCheck, Truck, RotateCcw } from "lucide-react";

export default function ProductDetail() {
  const { id } = useParams();
  const productId = parseInt(id || "0");
  
  const { data: product, isLoading } = useProduct(productId);
  const { mutate: addToCart, isPending: addingToCart } = useAddToCart();
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();

  const defaultImage = `https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&h=800&fit=crop&q=80`;

  const handleAddToCart = (redirect: boolean = false) => {
    if (!isAuthenticated) {
      redirectToLogin(toast);
      return;
    }

    addToCart(
      { productId, quantity: 1 },
      {
        onSuccess: () => {
          toast({ title: "Added to Cart", description: "Item added to your cart." });
          if (redirect) window.location.href = "/checkout";
        },
        onError: () => toast({ title: "Error", description: "Could not add to cart.", variant: "destructive" })
      }
    );
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="bg-card rounded-xl border p-6 flex flex-col md:flex-row gap-8">
          <Skeleton className="w-full md:w-1/2 aspect-square rounded-xl" />
          <div className="w-full md:w-1/2 space-y-4">
            <Skeleton className="h-10 w-3/4" />
            <Skeleton className="h-6 w-1/4" />
            <Skeleton className="h-12 w-1/3" />
            <Skeleton className="h-32 w-full" />
            <div className="flex gap-4 pt-6">
              <Skeleton className="h-14 w-1/2" />
              <Skeleton className="h-14 w-1/2" />
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  if (!product) {
    return (
      <Layout>
        <div className="text-center py-20">
          <h2 className="text-2xl font-bold mb-2">Product not found</h2>
          <p className="text-muted-foreground mb-6">The product you're looking for doesn't exist.</p>
          <Button onClick={() => window.history.back()} variant="outline">Go Back</Button>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="bg-card rounded-2xl border shadow-sm overflow-hidden flex flex-col md:flex-row">
        
        {/* Left: Image Gallery */}
        <div className="w-full md:w-5/12 p-8 border-b md:border-b-0 md:border-r border-border/50 flex flex-col items-center justify-center bg-white relative">
          <div className="w-full aspect-square flex items-center justify-center max-w-md mx-auto">
            <img 
              src={product.imageUrl || defaultImage} 
              alt={product.name} 
              className="max-w-full max-h-full object-contain mix-blend-multiply transition-transform duration-300 hover:scale-110 cursor-zoom-in"
            />
          </div>
          
          {/* Action Buttons (Desktop layout usually puts them under image in Flipkart) */}
          <div className="w-full flex gap-4 mt-8 pt-4">
            <Button 
              onClick={() => handleAddToCart(false)}
              disabled={addingToCart || product.stock <= 0}
              className="flex-1 h-14 bg-[#ff9f00] hover:bg-[#f09600] text-white text-lg font-bold shadow-md hover:shadow-lg transition-all rounded-sm rounded-tr-xl"
            >
              <ShoppingCart className="w-5 h-5 mr-2" />
              ADD TO CART
            </Button>
            <Button 
              onClick={() => handleAddToCart(true)}
              disabled={addingToCart || product.stock <= 0}
              className="flex-1 h-14 bg-[#fb641b] hover:bg-[#ef5e1a] text-white text-lg font-bold shadow-md hover:shadow-lg transition-all rounded-sm rounded-tl-xl"
            >
              <Zap className="w-5 h-5 mr-2" />
              BUY NOW
            </Button>
          </div>
        </div>

        {/* Right: Details */}
        <div className="w-full md:w-7/12 p-6 md:p-8 flex flex-col">
          <div className="text-sm text-muted-foreground mb-2 flex items-center gap-2">
            <span className="hover:text-primary cursor-pointer">Home</span> 
            <span>›</span>
            <span className="hover:text-primary cursor-pointer">{product.category}</span>
          </div>
          
          <h1 className="text-2xl md:text-3xl font-display font-medium text-foreground mb-2 leading-tight">
            {product.name}
          </h1>
          
          <div className="flex items-center gap-4 mb-4">
            <div className="bg-green-600 text-white px-2 py-0.5 rounded text-sm font-bold flex items-center gap-1">
              4.4 <Star className="w-3 h-3 fill-current" />
            </div>
            <span className="text-muted-foreground text-sm font-medium">
              8,432 Ratings & 984 Reviews
            </span>
            <img src="https://static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/fa_62673a.png" alt="Assured" className="h-5 opacity-0" />
          </div>
          
          <div className="text-green-600 text-sm font-bold mb-1">Extra ₹500 off</div>
          <div className="flex items-end gap-3 mb-2">
            <span className="text-4xl font-display font-bold text-foreground">
              {formatCurrency(Number(product.price))}
            </span>
            <span className="text-lg text-muted-foreground line-through pb-1">
              {formatCurrency(Number(product.price) * 1.2)}
            </span>
            <span className="text-base font-bold text-green-600 pb-1">20% off</span>
          </div>
          
          <div className="text-sm text-muted-foreground mb-8">
            <span className="font-semibold text-foreground">Free Delivery</span> by Tomorrow
          </div>
          
          {/* Offers */}
          <div className="mb-8">
            <h3 className="font-bold text-foreground mb-3">Available Offers</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex gap-2 items-start"><span className="text-green-600 font-bold mt-0.5">🏷️</span> <span><strong className="font-semibold">Bank Offer</strong> 5% Unlimited Cashback on Flipkart Axis Bank Credit Card</span></li>
              <li className="flex gap-2 items-start"><span className="text-green-600 font-bold mt-0.5">🏷️</span> <span><strong className="font-semibold">Bank Offer</strong> 10% off on ICICI Bank Credit Card, up to ₹1,250</span></li>
              <li className="flex gap-2 items-start"><span className="text-green-600 font-bold mt-0.5">🏷️</span> <span><strong className="font-semibold">Special Price</strong> Get extra ₹500 off (price inclusive of cashback/coupon)</span></li>
            </ul>
          </div>
          
          {/* Description */}
          <div className="border-t pt-6 mb-6">
            <h3 className="font-bold text-foreground mb-3">Product Description</h3>
            <p className="text-muted-foreground leading-relaxed">
              {product.description}
            </p>
          </div>
          
          {/* Trust Badges */}
          <div className="grid grid-cols-3 gap-4 border-t pt-6 mt-auto">
            <div className="flex flex-col items-center text-center gap-2 text-sm text-muted-foreground">
              <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-primary">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <span>1 Year Warranty</span>
            </div>
            <div className="flex flex-col items-center text-center gap-2 text-sm text-muted-foreground">
              <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-primary">
                <RotateCcw className="w-5 h-5" />
              </div>
              <span>7 Days Replacement</span>
            </div>
            <div className="flex flex-col items-center text-center gap-2 text-sm text-muted-foreground">
              <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-primary">
                <Truck className="w-5 h-5" />
              </div>
              <span>Fast Delivery</span>
            </div>
          </div>
          
        </div>
      </div>
    </Layout>
  );
}
