import { Layout } from "@/components/layout/Layout";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { User, LogOut, Package, Heart, MapPin, Phone, Mail, Edit2 } from "lucide-react";
import { useLocation } from "wouter";

export default function Profile() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();

  if (!user) {
    setLocation('/');
    return null;
  }

  const handleLogout = () => {
    logout();
    setLocation('/');
  };

  return (
    <Layout>
      <div className="max-w-4xl mx-auto">
        {/* Profile Header */}
        <div className="bg-gradient-to-r from-primary to-primary/80 text-white rounded-2xl p-8 mb-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
            <div className="w-24 h-24 rounded-full bg-white/20 flex items-center justify-center border-4 border-white/30">
              <User className="w-12 h-12" />
            </div>
            <div className="flex-1">
              <h1 className="text-3xl font-bold mb-1">{user.firstName && user.lastName ? `${user.firstName} ${user.lastName}` : 'User'}</h1>
              <p className="text-white/80 flex items-center gap-2 mb-4">
                <Mail className="w-4 h-4" /> {user.email}
              </p>
              <p className="text-white/70 text-sm">Member since {new Date(user.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long' })}</p>
            </div>
            <Button 
              onClick={handleLogout}
              className="bg-white text-primary hover:bg-gray-100 gap-2"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </Button>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          <Card className="p-6 text-center">
            <div className="w-12 h-12 mx-auto bg-blue-100 text-primary rounded-lg flex items-center justify-center mb-3">
              <Package className="w-6 h-6" />
            </div>
            <p className="text-gray-600 text-sm mb-1">Total Orders</p>
            <p className="text-2xl font-bold text-foreground">View Orders</p>
          </Card>
          <Card className="p-6 text-center">
            <div className="w-12 h-12 mx-auto bg-pink-100 text-red-500 rounded-lg flex items-center justify-center mb-3">
              <Heart className="w-6 h-6" />
            </div>
            <p className="text-gray-600 text-sm mb-1">Wishlist</p>
            <p className="text-2xl font-bold text-foreground">Coming Soon</p>
          </Card>
          <Card className="p-6 text-center">
            <div className="w-12 h-12 mx-auto bg-green-100 text-green-600 rounded-lg flex items-center justify-center mb-3">
              <MapPin className="w-6 h-6" />
            </div>
            <p className="text-gray-600 text-sm mb-1">Saved Addresses</p>
            <p className="text-2xl font-bold text-foreground">Manage</p>
          </Card>
        </div>

        {/* Account Settings */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Personal Information */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <User className="w-5 h-5 text-primary" />
                Personal Information
              </h2>
              <Button variant="ghost" size="sm" className="text-primary">
                <Edit2 className="w-4 h-4" />
              </Button>
            </div>
            <div className="space-y-4">
              <div className="pb-4 border-b">
                <p className="text-gray-600 text-sm mb-1">First Name</p>
                <p className="font-medium text-foreground">{user.firstName || 'Not provided'}</p>
              </div>
              <div className="pb-4 border-b">
                <p className="text-gray-600 text-sm mb-1">Last Name</p>
                <p className="font-medium text-foreground">{user.lastName || 'Not provided'}</p>
              </div>
              <div className="pb-4">
                <p className="text-gray-600 text-sm mb-1">Email Address</p>
                <p className="font-medium text-foreground">{user.email}</p>
              </div>
            </div>
          </Card>

          {/* Contact Information */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <Phone className="w-5 h-5 text-primary" />
                Contact Information
              </h2>
              <Button variant="ghost" size="sm" className="text-primary">
                <Edit2 className="w-4 h-4" />
              </Button>
            </div>
            <div className="space-y-4">
              <div className="pb-4 border-b">
                <p className="text-gray-600 text-sm mb-1">Phone Number</p>
                <p className="font-medium text-foreground">Add phone number</p>
              </div>
              <div className="pb-4 border-b">
                <p className="text-gray-600 text-sm mb-1">Alternate Email</p>
                <p className="font-medium text-foreground">Add alternate email</p>
              </div>
              <div className="pb-4">
                <p className="text-gray-600 text-sm mb-1">Date of Birth</p>
                <p className="font-medium text-foreground">Add date of birth</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Button 
            onClick={() => setLocation('/orders')}
            variant="outline" 
            className="h-12 border-primary text-primary hover:bg-primary/5 font-semibold"
          >
            <Package className="w-5 h-5 mr-2" />
            View My Orders
          </Button>
          <Button 
            variant="outline" 
            className="h-12 border-primary text-primary hover:bg-primary/5 font-semibold"
          >
            <MapPin className="w-5 h-5 mr-2" />
            Manage Addresses
          </Button>
        </div>
      </div>
    </Layout>
  );
}
