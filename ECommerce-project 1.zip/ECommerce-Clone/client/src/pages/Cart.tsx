import { Link } from "wouter";
import { Layout } from "@/components/layout/Layout";
import { useCart, useUpdateCartItem, useRemoveCartItem } from "@/hooks/use-cart";
import { formatCurrency } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Minus, Plus, Trash2, ShieldCheck } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

export default function Cart() {
  const { data: cartItems, isLoading } = useCart();
  const { mutate: updateItem, isPending: updating } = useUpdateCartItem();
  const { mutate: removeItem, isPending: removing } = useRemoveCartItem();
  const { isAuthenticated } = useAuth();

  const totalAmount = cartItems?.reduce((acc, item) => acc + (Number(item.product.price) * item.quantity), 0) || 0;
  const originalAmount = totalAmount * 1.2; // Fake original price for discount display
  const discount = originalAmount - totalAmount;

  if (!isAuthenticated) {
    return (
      <Layout>
        <div className="bg-card rounded-xl border p-12 text-center shadow-sm max-w-2xl mx-auto mt-10">
          <div className="w-32 h-32 mx-auto mb-6 opacity-80">
            <img src="https://rukminim2.flixcart.com/www/800/800/promos/16/05/2019/d438a32e-765a-4d8b-b4a6-520b560971e8.png?q=90" alt="Empty Cart" className="w-full h-full object-contain" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Missing Cart items?</h2>
          <p className="text-muted-foreground mb-8">Login to see the items you added previously</p>
          <Button onClick={() => window.location.href = '/api/login'} className="bg-[#fb641b] hover:bg-[#ef5e1a] text-white px-12 py-6 rounded-sm text-lg shadow-md font-medium">
            Login
          </Button>
        </div>
      </Layout>
    );
  }

  if (isLoading) {
    return (
      <Layout>
        <div className="animate-pulse space-y-4 max-w-5xl mx-auto">
          <div className="h-32 bg-card rounded-xl border"></div>
          <div className="h-32 bg-card rounded-xl border"></div>
        </div>
      </Layout>
    );
  }

  if (!cartItems || cartItems.length === 0) {
    return (
      <Layout>
        <div className="bg-card rounded-xl border p-12 text-center shadow-sm max-w-3xl mx-auto mt-10">
          <div className="w-48 h-48 mx-auto mb-6">
            <img src="https://rukminim2.flixcart.com/www/800/800/promos/16/05/2019/d438a32e-765a-4d8b-b4a6-520b560971e8.png?q=90" alt="Empty Cart" className="w-full h-full object-contain" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Your cart is empty!</h2>
          <p className="text-muted-foreground mb-8">Add items to it now.</p>
          <Link href="/">
            <Button className="bg-primary hover:bg-primary/90 text-white px-10 py-6 rounded-sm shadow-md font-medium">
              Shop Now
            </Button>
          </Link>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="flex flex-col lg:flex-row gap-6 items-start">
        {/* Cart Items List */}
        <div className="w-full lg:w-2/3 bg-card rounded-xl border shadow-sm overflow-hidden">
          <div className="p-4 border-b bg-white flex justify-between items-center">
            <h2 className="text-xl font-bold text-foreground">MK Mart ({cartItems.length})</h2>
          </div>
          
          <div className="divide-y divide-border/50">
            {cartItems.map((item) => (
              <div key={item.id} className="p-6 flex flex-col sm:flex-row gap-6 bg-white hover:bg-gray-50/50 transition-colors">
                <div className="w-28 h-28 shrink-0 flex items-center justify-center p-2">
                  <img 
                    src={item.product.imageUrl || `https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=200&h=200&fit=crop`} 
                    alt={item.product.name} 
                    className="max-w-full max-h-full object-contain"
                  />
                </div>
                
                <div className="flex-1">
                  <Link href={`/product/${item.product.id}`} className="font-medium text-lg hover:text-primary line-clamp-2 mb-1">
                    {item.product.name}
                  </Link>
                  <p className="text-sm text-muted-foreground mb-3">Seller: RetailNet</p>
                  
                  <div className="flex items-center gap-3 mb-6">
                    <span className="text-sm text-muted-foreground line-through">{formatCurrency(Number(item.product.price) * 1.2)}</span>
                    <span className="text-xl font-bold text-foreground">{formatCurrency(Number(item.product.price))}</span>
                    <span className="text-sm font-semibold text-green-600">20% Off</span>
                  </div>
                  
                  <div className="flex items-center gap-6">
                    <div className="flex items-center border rounded-sm overflow-hidden bg-white">
                      <button 
                        onClick={() => item.quantity > 1 && updateItem({ id: item.id, data: { quantity: item.quantity - 1 } })}
                        disabled={item.quantity <= 1 || updating}
                        className="w-8 h-8 flex items-center justify-center hover:bg-gray-100 disabled:opacity-50 disabled:bg-gray-50"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <div className="w-12 h-8 flex items-center justify-center font-medium border-x text-sm">
                        {item.quantity}
                      </div>
                      <button 
                        onClick={() => updateItem({ id: item.id, data: { quantity: item.quantity + 1 } })}
                        disabled={updating}
                        className="w-8 h-8 flex items-center justify-center hover:bg-gray-100 disabled:opacity-50"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                    
                    <button 
                      onClick={() => removeItem(item.id)}
                      disabled={removing}
                      className="text-foreground hover:text-primary font-medium text-sm flex items-center uppercase tracking-wide"
                    >
                      REMOVE
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="p-4 border-t bg-white flex justify-end sticky bottom-0 z-10 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)]">
            <Link href="/checkout">
              <Button className="bg-[#fb641b] hover:bg-[#ef5e1a] text-white px-10 py-6 rounded-sm text-lg shadow-md font-bold uppercase tracking-wide">
                Place Order
              </Button>
            </Link>
          </div>
        </div>

        {/* Price Details */}
        <div className="w-full lg:w-1/3 space-y-4">
          <div className="bg-card rounded-xl border shadow-sm p-0 sticky top-24">
            <div className="p-4 border-b">
              <h3 className="font-bold text-gray-500 uppercase tracking-wide text-sm">Price Details</h3>
            </div>
            <div className="p-6 space-y-4">
              <div className="flex justify-between">
                <span>Price ({cartItems.length} items)</span>
                <span>{formatCurrency(originalAmount)}</span>
              </div>
              <div className="flex justify-between text-green-600">
                <span>Discount</span>
                <span>− {formatCurrency(discount)}</span>
              </div>
              <div className="flex justify-between">
                <span>Delivery Charges</span>
                <span className="text-green-600 font-medium">Free</span>
              </div>
              
              <div className="border-t border-dashed border-gray-300 pt-4 mt-4 flex justify-between items-center">
                <span className="font-bold text-lg">Total Amount</span>
                <span className="font-bold text-xl">{formatCurrency(totalAmount)}</span>
              </div>
              <div className="border-t border-dashed border-gray-300 pt-4 mt-4 text-green-600 font-semibold text-sm">
                You will save {formatCurrency(discount)} on this order
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-3 p-4 bg-white border rounded-xl shadow-sm text-sm text-muted-foreground font-medium">
            <ShieldCheck className="w-8 h-8 text-gray-400" />
            <p>Safe and Secure Payments. Easy returns. 100% Authentic products.</p>
          </div>
        </div>
      </div>
    </Layout>
  );
}
