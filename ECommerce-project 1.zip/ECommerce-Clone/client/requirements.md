## Packages
framer-motion | Page transitions and scroll-triggered animations
lucide-react | Beautiful, consistent iconography
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility to merge tailwind classes without style conflicts

## Notes
- Images are primarily sourced from the backend; Unsplash fallbacks will be used if `imageUrl` is missing.
- Authentication relies on the provided `useAuth` hook and `/api/login` endpoint.
- Protected API calls (cart, orders) require `credentials: "include"`.
