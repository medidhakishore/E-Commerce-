import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { isAuthenticated, setupAuth } from "./replit_integrations/auth";
import { registerAuthRoutes } from "./replit_integrations/auth";
import { registerObjectStorageRoutes } from "./replit_integrations/object_storage";
import { db } from "./db";
import { products } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup authentication first
  await setupAuth(app);

  // Register integration routes
  registerAuthRoutes(app);
  registerObjectStorageRoutes(app);

  // Seed database
  await seedDatabase();

  // Products
  app.get(api.products.list.path, async (req, res) => {
    const search = req.query.search as string | undefined;
    const category = req.query.category as string | undefined;
    const allProducts = await storage.getProducts(search, category);
    res.json(allProducts);
  });

  app.get(api.products.get.path, async (req, res) => {
    const product = await storage.getProduct(Number(req.params.id));
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }
    res.json(product);
  });

  app.get(api.products.categories.path, async (req, res) => {
    const categories = await storage.getCategories();
    res.json(categories);
  });

  // Cart
  app.get(api.cart.list.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const items = await storage.getCartItems(userId);
    res.json(items);
  });

  app.post(api.cart.add.path, isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const input = api.cart.add.input.parse(req.body);
      const item = await storage.addCartItem(userId, input);
      res.status(201).json(item);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.put(api.cart.update.path, isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const input = api.cart.update.input.parse(req.body);
      const item = await storage.updateCartItem(Number(req.params.id), userId, input);
      if (!item) {
        return res.status(404).json({ message: "Cart item not found" });
      }
      res.json(item);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete(api.cart.remove.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    await storage.removeCartItem(Number(req.params.id), userId);
    res.status(204).end();
  });

  app.delete(api.cart.clear.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    await storage.clearCart(userId);
    res.status(204).end();
  });

  // Orders
  app.get(api.orders.list.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const userOrders = await storage.getOrders(userId);
    res.json(userOrders);
  });

  app.get(api.orders.get.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const order = await storage.getOrder(Number(req.params.id), userId);
    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }
    res.json(order);
  });

  app.post(api.orders.create.path, isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const input = api.orders.create.input.parse(req.body);
      const order = await storage.createOrder(userId, input);
      res.status(201).json(order);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      if (err instanceof Error && err.message === "Cart is empty") {
        return res.status(400).json({ message: "Cart is empty" });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  return httpServer;
}

async function seedDatabase() {
  const existingProducts = await storage.getProducts();
  if (existingProducts.length === 0) {
    const seedProducts = [
      {
        name: "Apple iPhone 15 Pro",
        description: "Experience the power of A17 Pro chip and Titanium design.",
        price: "134900.00",
        category: "Electronics",
        imageUrl: "https://images.unsplash.com/photo-1696446701796-da61225697cc?w=800&q=80",
        stock: 25,
        isFeatured: true
      },
      {
        name: "Sony WH-1000XM5",
        description: "Industry leading noise canceling headphones.",
        price: "29990.00",
        category: "Electronics",
        imageUrl: "https://images.unsplash.com/photo-1670054366601-57434199c836?w=800&q=80",
        stock: 40,
        isFeatured: true
      },
      {
        name: "Nike Air Jordan 1",
        description: "Classic basketball shoes with legendary style.",
        price: "15995.00",
        category: "Fashion",
        imageUrl: "https://images.unsplash.com/photo-1552346154-21d32810aba3?w=800&q=80",
        stock: 30,
        isFeatured: true
      },
      {
        name: "Fossil Gen 6 Smartwatch",
        description: "Smart features with classic watch design.",
        price: "24995.00",
        category: "Accessories",
        imageUrl: "https://images.unsplash.com/photo-1508685096489-7aac291ba59e?w=800&q=80",
        stock: 50,
        isFeatured: false
      },
      {
        name: "Dell XPS 13 Laptop",
        description: "The ultimate 13-inch laptop with stunning display.",
        price: "115000.00",
        category: "Electronics",
        imageUrl: "https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=800&q=80",
        stock: 15,
        isFeatured: true
      },
      {
        name: "Levi's 511 Slim Fit Jeans",
        description: "A modern slim with room to move.",
        price: "3599.00",
        category: "Fashion",
        imageUrl: "https://images.unsplash.com/photo-1542272604-787c3835535d?w=800&q=80",
        stock: 100,
        isFeatured: false
      },
      {
        name: "Ray-Ban Aviator",
        description: "The world's most iconic sunglasses.",
        price: "10590.00",
        category: "Accessories",
        imageUrl: "https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=800&q=80",
        stock: 40,
        isFeatured: true
      },
      {
        name: "LEGO Star Wars Millennium Falcon",
        description: "The iconic Star Wars set with 1000+ pieces for kids and collectors.",
        price: "8999.00",
        category: "Kids",
        imageUrl: "https://images.unsplash.com/photo-1552820728-8ac41f1ce891?w=800&q=80",
        stock: 50,
        isFeatured: true
      },
      {
        name: "Organic Baby Diapers Size M",
        description: "Soft and skin-friendly diapers for babies with wetness indicator.",
        price: "1299.00",
        category: "Kids",
        imageUrl: "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=800&q=80",
        stock: 150,
        isFeatured: false
      },
      {
        name: "Fresh Organic Apples (1kg)",
        description: "Crisp and sweet organic apples sourced from local farms.",
        price: "249.00",
        category: "Groceries",
        imageUrl: "https://images.unsplash.com/photo-1560806674-9d71f62b9c85?w=800&q=80",
        stock: 200,
        isFeatured: true
      },
      {
        name: "Basmati Rice (5kg Pack)",
        description: "Premium long grain Basmati rice, perfect for everyday cooking.",
        price: "699.00",
        category: "Groceries",
        imageUrl: "https://images.unsplash.com/photo-1598044425341-a9f74b5b0c01?w=800&q=80",
        stock: 300,
        isFeatured: false
      },
      {
        name: "Organic Honey (500ml)",
        description: "Pure raw honey with natural enzymes and nutrients.",
        price: "449.00",
        category: "Groceries",
        imageUrl: "https://images.unsplash.com/photo-1587049633312-d628ae42c933?w=800&q=80",
        stock: 80,
        isFeatured: true
      },
      {
        name: "Kids Learning Tablet",
        description: "Educational tablet designed specifically for children with parental controls.",
        price: "9999.00",
        category: "Kids",
        imageUrl: "https://images.unsplash.com/photo-1602080113235-7d716ed3a2a7?w=800&q=80",
        stock: 30,
        isFeatured: false
      },
      {
        name: "Whole Wheat Flour (2kg)",
        description: "Nutrient-rich whole wheat flour for healthy baking.",
        price: "189.00",
        category: "Groceries",
        imageUrl: "https://images.unsplash.com/photo-1585707520061-3ba3c3a5b57e?w=800&q=80",
        stock: 250,
        isFeatured: false
      },
      {
        name: "Wireless Noise-Cancelling Headphones",
        description: "Premium over-ear headphones with industry-leading noise cancellation.",
        price: "249.50",
        category: "Electronics",
        imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=80",
        stock: 120,
        isFeatured: true
      },
      {
        name: "Men's Casual Cotton Shirt",
        description: "Comfortable and stylish cotton shirt for everyday wear.",
        price: "34.99",
        category: "Fashion",
        imageUrl: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=800&q=80",
        stock: 200,
        isFeatured: false
      },
      {
        name: "Women's Running Shoes",
        description: "Lightweight and breathable running shoes designed for maximum comfort.",
        price: "89.00",
        category: "Fashion",
        imageUrl: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&q=80",
        stock: 150,
        isFeatured: true
      },
      {
        name: "Smart Watch Series 5",
        description: "Track your fitness, heart rate, and stay connected on the go.",
        price: "199.99",
        category: "Electronics",
        imageUrl: "https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=800&q=80",
        stock: 75,
        isFeatured: false
      },
      {
        name: "Designer Sunglasses",
        description: "Classic aviator sunglasses with UV protection.",
        price: "129.99",
        category: "Accessories",
        imageUrl: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=800&q=80",
        stock: 60,
        isFeatured: false
      },
      {
        name: "4K Ultra HD Smart TV",
        description: "Experience stunning picture quality with our 55-inch 4K Smart TV.",
        price: "549.00",
        category: "Electronics",
        imageUrl: "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=800&q=80",
        stock: 30,
        isFeatured: true
      },
      {
        name: "Leather Messenger Bag",
        description: "Premium handcrafted leather messenger bag perfect for work or travel.",
        price: "159.00",
        category: "Accessories",
        imageUrl: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800&q=80",
        stock: 45,
        isFeatured: false
      }
    ];

    for (const product of seedProducts) {
      await db.insert(products).values(product);
    }
    console.log("Database seeded with initial products.");
  }
}
