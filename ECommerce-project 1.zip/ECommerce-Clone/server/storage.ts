import { db } from "./db";
import { 
  products, cartItems, orders, orderItems,
  type Product, type InsertProduct,
  type CartItem, type InsertCartItem, type UpdateCartItem, type CartItemWithProduct,
  type Order, type InsertOrder, type OrderItem, type OrderWithItems
} from "@shared/schema";
import { eq, and, inArray, desc } from "drizzle-orm";

export interface IStorage {
  // Products
  getProducts(search?: string, category?: string): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  getCategories(): Promise<string[]>;
  
  // Cart
  getCartItems(userId: string): Promise<CartItemWithProduct[]>;
  addCartItem(userId: string, item: InsertCartItem): Promise<CartItemWithProduct>;
  updateCartItem(id: number, userId: string, update: UpdateCartItem): Promise<CartItemWithProduct | undefined>;
  removeCartItem(id: number, userId: string): Promise<void>;
  clearCart(userId: string): Promise<void>;
  
  // Orders
  getOrders(userId: string): Promise<OrderWithItems[]>;
  getOrder(id: number, userId: string): Promise<OrderWithItems | undefined>;
  createOrder(userId: string, orderData: InsertOrder): Promise<Order>;
}

export class DatabaseStorage implements IStorage {
  async getProducts(search?: string, category?: string): Promise<Product[]> {
    let query = db.select().from(products).$dynamic();
    
    // In a real app, we'd add where clauses for search and category
    // Using simple fetching for now
    let allProducts = await query;
    
    if (category) {
      allProducts = allProducts.filter(p => p.category === category);
    }
    
    if (search) {
      const searchLower = search.toLowerCase();
      allProducts = allProducts.filter(p => 
        p.name.toLowerCase().includes(searchLower) || 
        p.description.toLowerCase().includes(searchLower)
      );
    }
    
    return allProducts;
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async getCategories(): Promise<string[]> {
    const allProducts = await db.select({ category: products.category }).from(products);
    const categories = new Set(allProducts.map(p => p.category));
    return Array.from(categories);
  }

  async getCartItems(userId: string): Promise<CartItemWithProduct[]> {
    const items = await db.select({
      cartItem: cartItems,
      product: products
    })
    .from(cartItems)
    .innerJoin(products, eq(cartItems.productId, products.id))
    .where(eq(cartItems.userId, userId));
    
    return items.map(row => ({
      ...row.cartItem,
      product: row.product
    }));
  }

  async addCartItem(userId: string, item: InsertCartItem): Promise<CartItemWithProduct> {
    // Check if item already exists in cart
    const [existing] = await db.select()
      .from(cartItems)
      .where(and(
        eq(cartItems.userId, userId),
        eq(cartItems.productId, item.productId)
      ));
      
    let cartItem;
    if (existing) {
      const [updated] = await db.update(cartItems)
        .set({ quantity: existing.quantity + item.quantity })
        .where(eq(cartItems.id, existing.id))
        .returning();
      cartItem = updated;
    } else {
      const [inserted] = await db.insert(cartItems)
        .values({ ...item, userId })
        .returning();
      cartItem = inserted;
    }
    
    const product = await this.getProduct(cartItem.productId);
    if (!product) throw new Error("Product not found");
    
    return { ...cartItem, product };
  }

  async updateCartItem(id: number, userId: string, update: UpdateCartItem): Promise<CartItemWithProduct | undefined> {
    const [updated] = await db.update(cartItems)
      .set(update)
      .where(and(eq(cartItems.id, id), eq(cartItems.userId, userId)))
      .returning();
      
    if (!updated) return undefined;
    
    const product = await this.getProduct(updated.productId);
    if (!product) throw new Error("Product not found");
    
    return { ...updated, product };
  }

  async removeCartItem(id: number, userId: string): Promise<void> {
    await db.delete(cartItems)
      .where(and(eq(cartItems.id, id), eq(cartItems.userId, userId)));
  }

  async clearCart(userId: string): Promise<void> {
    await db.delete(cartItems).where(eq(cartItems.userId, userId));
  }

  async getOrders(userId: string): Promise<OrderWithItems[]> {
    const userOrders = await db.select()
      .from(orders)
      .where(eq(orders.userId, userId))
      .orderBy(desc(orders.createdAt));
      
    const ordersWithItems = [];
    
    for (const order of userOrders) {
      const items = await db.select({
        orderItem: orderItems,
        product: products
      })
      .from(orderItems)
      .innerJoin(products, eq(orderItems.productId, products.id))
      .where(eq(orderItems.orderId, order.id));
      
      ordersWithItems.push({
        ...order,
        items: items.map(row => ({ ...row.orderItem, product: row.product }))
      });
    }
    
    return ordersWithItems;
  }

  async getOrder(id: number, userId: string): Promise<OrderWithItems | undefined> {
    const [order] = await db.select()
      .from(orders)
      .where(and(eq(orders.id, id), eq(orders.userId, userId)));
      
    if (!order) return undefined;
    
    const items = await db.select({
      orderItem: orderItems,
      product: products
    })
    .from(orderItems)
    .innerJoin(products, eq(orderItems.productId, products.id))
    .where(eq(orderItems.orderId, order.id));
    
    return {
      ...order,
      items: items.map(row => ({ ...row.orderItem, product: row.product }))
    };
  }

  async createOrder(userId: string, orderData: InsertOrder): Promise<Order> {
    // Get cart items
    const cartItemsList = await this.getCartItems(userId);
    if (cartItemsList.length === 0) {
      throw new Error("Cart is empty");
    }
    
    // Calculate total
    const totalAmount = cartItemsList.reduce((sum, item) => {
      return sum + (Number(item.product.price) * item.quantity);
    }, 0);
    
    // Create order
    const [order] = await db.insert(orders)
      .values({
        userId,
        shippingAddress: orderData.shippingAddress,
        totalAmount: totalAmount.toString(),
        status: "pending"
      })
      .returning();
      
    // Create order items
    for (const item of cartItemsList) {
      await db.insert(orderItems).values({
        orderId: order.id,
        productId: item.productId,
        quantity: item.quantity,
        price: item.product.price
      });
    }
    
    // Clear cart
    await this.clearCart(userId);
    
    return order;
  }
}

export const storage = new DatabaseStorage();
